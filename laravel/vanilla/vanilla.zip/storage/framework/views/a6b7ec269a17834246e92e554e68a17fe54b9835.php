<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

      <div class="mt-8 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
        <div class="grid grid-cols-3">

          <div class="p-6">
            <div class="flex items-center">
              <div class="ml-4 text-lg leading-7 font-semibold">BTC</div>
            </div>
            <div class="ml-12">
              <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <div class="container" id="btc"></div>
              </div>
            </div>
          </div>

          <div class="p-6">
            <div class="flex items-center">
              <div class="ml-4 text-lg leading-7 font-semibold">ETH</div>
            </div>
            <div class="ml-12">
              <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <div class="container" id="eth"></div>
              </div>
            </div>
          </div>

          <div class="p-6">
            <div class="flex items-center">
              <div class="ml-4 text-lg leading-7 font-semibold">BNB</div>
            </div>
            <div class="ml-12">
              <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <div class="container" id="bnb"></div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="mt-8 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
        <div class="grid grid-cols-3">

          <div class="p-6">
            <div class="flex items-center">
              <div class="ml-4 text-lg leading-7 font-semibold">DOGE</div>
            </div>
            <div class="ml-12">
              <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <div class="container" id="doge"></div>
              </div>
            </div>
          </div>

          <div class="p-6">
            <div class="flex items-center">
              <div class="ml-4 text-lg leading-7 font-semibold">MATIC</div>
            </div>
            <div class="ml-12">
              <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <div class="container" id="matic"></div>
              </div>
            </div>
          </div>

          <div class="p-6">
            <div class="flex items-center">
              <div class="ml-4 text-lg leading-7 font-semibold">svasta</div>
            </div>
            <div class="ml-12">
              <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <div class="container" id="svasta"></div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="mt-8 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
        <div class="grid grid-cols-1 md:grid-cols-2">

          <div class="p-6">
            <div class="flex items-center">
              <div class="ml-4 text-lg leading-7 font-semibold">USDT</div>
            </div>
            <div class="ml-12">
              <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <?php if(count($symbols_usdt) > 0): ?>
                <?php $__currentLoopData = $symbols_usdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container" id="<?php echo e($symbol); ?>"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p> No usdt symbols found</p>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="p-6">
            <div class="flex items-center">
              <div class="ml-4 text-lg leading-7 font-semibold">BUSD</div>
            </div>
            <div class="ml-12">
              <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <?php if(count($symbols_busd) > 0): ?>
                <?php $__currentLoopData = $symbols_busd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container" id="<?php echo e($symbol); ?>"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p> No busd symbols found</p>
                <?php endif; ?>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>
  <script>
    var bnb = '';
    var btc = '';
    var eth = '';
    var binanceSocket = new WebSocket("wss://stream.binance.com:9443/stream?streams=<?php echo e($link); ?>");

    binanceSocket.onmessage = function(event) {
      var message = JSON.parse(event.data);
      if (message.stream == 'bnbbusd@kline_1m') {
        bnb = message.data.k.c*1;
        document.getElementById('bnb').innerHTML = bnb;
      }
      if (message.stream == 'btcbusd@kline_1m') {
        btc = message.data.k.c*1;
        document.getElementById('btc').innerHTML = btc;
      }
      if (message.stream == 'ethbusd@kline_1m') {
        eth = message.data.k.c*1;
        document.getElementById('eth').innerHTML = eth;
      }
      if (message.stream == 'dogebusd@kline_1m') {
        doge = message.data.k.c*1;
        document.getElementById('doge').innerHTML = doge;
      }
      if (message.stream == 'maticbusd@kline_1m') {
        matic = message.data.k.c*1;
        document.getElementById('matic').innerHTML = matic;
      }
      if (message.stream == 'bnbbtc@kline_1m') {
        var bnbbtc = message.data.k.c*1;
        document.getElementById('svasta').innerHTML = bnbbtc + ' ( ' + (bnb / btc).toFixed(6) + ' ) ';
      }
      document.title = btc + ' ' + bnb + ' ' + eth;
      //console.log('message', message)
      <?php $__currentLoopData = $symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      if (message.stream == '<?php echo e(strtolower($symbol)); ?>@kline_1m') {
        var postotak = 100 * (message.data.k.c - message.data.k.o) / message.data.k.o;
        if (postotak > 0.7) {
          document.getElementById('<?php echo e($symbol); ?>').innerHTML = '<?php echo e($symbol); ?> ' + (message.data.k.c*1) + '(' + postotak + '%)';
        } else {
          document.getElementById('<?php echo e($symbol); ?>').innerHTML = '';
        }
      }
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      //var candlestick = message.k;

      //console.log('candlestick', candlestick)

    }

  </script>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\git\testing\laravel\vanilla\resources\views/symbols/index.blade.php ENDPATH**/ ?>
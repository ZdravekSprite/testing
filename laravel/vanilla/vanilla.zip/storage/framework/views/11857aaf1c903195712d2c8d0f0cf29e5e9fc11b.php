<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      <?php echo e(__('Platna lista')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 bg-white border-b border-gray-200">
          <div class="flex justify-center">
            <label class="block">
              <span class="text-gray-700">Bruto:</span>
              <input type="text" class="form-input py-1 mt-1 block w-full" placeholder="<?php echo e($data['bruto']); ?>" disabled>
            </label>
            <label class="block">
              <span class="text-gray-700">Prijevoz:</span>
              <input type="text" class="form-input py-1 mt-1 block w-full" placeholder="<?php echo e($data['prijevoz']); ?>" disabled>
            </label>
            <label class="block">
              <span class="text-gray-700">Odbitak:</span>
              <input type="text" class="form-input py-1 mt-1 block w-full" placeholder="<?php echo e($data['odbitak']); ?>" disabled>
            </label>
            <label class="block">
              <span class="text-gray-700">Prirez:</span>
              <input type="text" class="form-input py-1 mt-1 block w-full" placeholder="<?php echo e($data['prirez']); ?>" disabled>
            </label>
            <label class="block">
              <span class="text-gray-700">Prekovremeni:</span>
              <select class="form-select py-1 block w-full mt-1" name="myprekovremeni" onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                <?php $__currentLoopData = $data['prekovremeniOptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e(route('lista', ['month' => $month['x']->format('m.Y'), 'prijevoz' => $data['prijevoz'], 'odbitak' => $data['odbitak'], 'prirez' => $data['prirez'], 'prekovremeni' => $value])); ?>" <?php if($value==old('myprekovremeni', $data['prekovremeni'])): ?> selected="selected" <?php endif; ?>><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </label>
          </div>
          <div class="flex justify-center">
            <a href="<?php echo e(route('lista', ['month' => $month['-']->format('m.Y')])); ?>">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-arrow-left-square" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M15 2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2zM0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm11.5 5.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z" />
              </svg>
            </a>
            <a class="mx-auto" href="<?php echo e(route('lista', ['month' => $month['x']->format('m.Y')])); ?>">
              Platna lista za <?php echo e($month['x']->format('m.Y')); ?>!
            </a>
            <a href="<?php echo e(route('lista', ['month' => $month['+']->format('m.Y')])); ?>">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-arrow-right-square" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M15 2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2zM0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm4.5 5.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z" />
              </svg>
            </a>
          </div>
          <table class="table-fixed">
            <thead>
              <tr>
                <th class="w-1/2 text-left"><b>OBRAČUN ISPLAĆENE PLAĆE</b></th>
                <th class="w-1/2 text-right" colspan="3"><b>Obrazac IP1</b></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="border p-2">
                  <ul>
                    <li><b>I. PODACI O POSLODAVCU</b></li>
                    <li>1. Tvrtka/ Ime i prezime: ____</li>
                    <li>2. Sjedište / Adresa: ____</li>
                    <li>3. Osobni identifikacijski broj: ____</li>
                    <li>4. IBAN broj računa ____ kod ____</li>
                  </ul>
                </td>
                <td class="border p-2" colspan="3">
                  <ul>
                    <li><b>II. PODACI O RADNIKU/RADNICI</b></li>
                    <li>
                      1. Ime i prezime: <b><?php echo e(Auth::user()->name); ?></b>
                    </li>
                    <li>2. Adresa: ____</li>
                    <li>3. Osobni identifikacijski broj: ____</li>
                    <li>4. IBAN broj računa ____ kod ____</li>
                    <li>5. IBAN broj računa iz čl. 212. Ovršnog zakona ____ kod ____</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td class="border p-2" colspan="4"><b>III. RAZDOBLJE NA KOJE SE PLAĆA ODNOSI:</b> GODINA <?php echo e($data['III.godina']); ?>, MJESEC
                  <?php echo e($data['III.mjesec']); ?> DANI U MJESECU OD <?php echo e($data['III.od']); ?> DO <?php echo e($data['III.do']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2"><b>1. OPIS PLAĆE</b></td>
                <td class="w-1/8 border p-2 text-center"><b>SATI</b></td>
                <td class="w-1/8 border p-2 text-right"><b>IZNOS</b></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">1.1. Za redoviti rad</td>
                <td class="w-1/8 border p-2 text-center"><?php echo e($data['1.1.h']); ?></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['1.1.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">1.4 Za prekovremeni rad</td>
                <td class="w-1/8 border p-2 text-center"><?php echo e($data['1.4.h']); ?></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['1.4.kn']); ?></td>
              </tr>
              <?php if($data['1.go.h'] > 0): ?>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">GO (pretpostavljam da se ovak računa)</td>
                <td class="w-1/8 border p-2 text-center"><?php echo e($data['1.go.h']); ?></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['1.go.kn']); ?></td>
              </tr>
              <?php endif; ?>
              <?php if($data['1.7a.h'] > 0): ?>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">1.7a Praznici. Blagdani, izbori</td>
                <td class="w-1/8 border p-2 text-center"><?php echo e($data['1.7a.h']); ?></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['1.7a.kn']); ?></td>
              </tr>
              <?php endif; ?>
              <?php if($data['1.7d.h'] > 0): ?>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">1.7d Bolovanje do 42 dana</td>
                <td class="w-1/8 border p-2 text-center"><?php echo e($data['1.7d.h']); ?></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['1.7d.kn']); ?></td>
              </tr>
              <?php endif; ?>
              <?php if($data['1.7e.h'] > 0): ?>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">1.7e Dodatak za rad nedjeljom</td>
                <td class="w-1/8 border p-2 text-center"><?php echo e($data['1.7e.h']); ?></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['1.7e.kn']); ?></td>
              </tr>
              <?php endif; ?>
              <?php if($data['1.7f.h'] > 0): ?>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">1.7f Dodatak za rad na praznik</td>
                <td class="w-1/8 border p-2 text-center"><?php echo e($data['1.7f.h']); ?></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['1.7f.kn']); ?></td>
              </tr>
              <?php endif; ?>
              <tr>
                <td class="w-3/4 border p-2" colspan="2">2. OSTALI OBLICI RADA TEMELJEM KOJIH OSTVARUJE PRAVO NA UVEĆANJE PLAĆE PREMA KOLEKTIVNOM UGOVORU, PRAVILNIKU O RADU ILI UGOVORU O RADU I NOVČANI IZNOS PO TOJ OSNOVI (SATI PRIPRAVNOSTI)</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2">3. PROPISANI ILI UGOVORENI DODACI NA PLAĆU RADNIKA I NOVČANI IZNOSI PO TOJ OSNOVI</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['3.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">3.1. Prijevoz</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['3.1.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2">4. ZBROJENI IZNOSI PRIMITAKA PO SVIM OSNOVAMA PO STAVKAMA 1. DO 3.</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['4.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2"><b>5. OSNOVICA ZA OBRAČUN DOPRINOSA</b></td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><b><?php echo e($data['5.kn']); ?><b></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2">6. VRSTE I IZNOSI DOPRINOSA ZA OBVEZNA OSIGURANJA KOJA SE OBUSTAVLJAJU IZ PLAĆ</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">6.1. za mirovinsko osiguranje na temelju generacijske solidarnosti (I. STUP)</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['6.1.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">6.2 za mirovinsko osiguranje na temelju individualne kapitalizirane štednje (II. STUP)</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['6.2.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2"><b>7. DOHODAK</b></td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><b><?php echo e($data['7.kn']); ?></b></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2">8. OSOBNI ODBITAK 1.00 / <?php echo e(number_format($data['odbitak'], 2, '.', '')); ?></td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['8.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2">9. POREZNA OSNOVICA</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['9.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2">10. IZNOS PREDUJMA POREZA I PRIREZA POREZU NA DOHODAK</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['10.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2 pl-6" colspan="2">20.00% <?php echo e($data['9.kn']); ?></td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['10.20.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2 pl-12" colspan="2">Prirez <?php echo e(number_format($data['prirez'], 2, '.', ',')); ?> %</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['10.prirez.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2"><b>11. NETO PLAĆA</b></td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><b><?php echo e($data['11.kn']); ?></b></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2">12. NAKNADE UKUPNO</td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><?php echo e($data['12.kn']); ?></td>
              </tr>
              <tr>
                <td class="w-3/4 border p-2" colspan="2"><b>13. NETO + NAKNADE</b></td>
                <td class="w-1/8 border p-2 text-center"></td>
                <td class="w-1/8 border p-2 text-right"><b><?php echo e($data['13.kn']); ?></b></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\git\testing\laravel\vanilla\resources\views/platna-lista.blade.php ENDPATH**/ ?>
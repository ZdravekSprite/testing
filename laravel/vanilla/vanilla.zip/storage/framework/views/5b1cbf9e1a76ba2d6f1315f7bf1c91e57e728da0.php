<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>test</title>
  <script src="https://unpkg.com/lightweight-charts/dist/lightweight-charts.standalone.production.js"></script>
</head>

<body>
  <script>
    var bnb = '';
    var btc = '';
    var eth = '';

    <?php $__currentLoopData = $symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = ['1h','1m']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    var container<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?> = document.createElement('div');
    container<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.id = "chart1h_<?php echo e($symbol[0]); ?>";
    container<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.style.cssText = 'float: left; padding: 1px;';

    document.body.appendChild(container<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>);

    var chartWidth = 470;
    var chartHeight = 230;

    var chart<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?> = LightweightCharts.createChart(container<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>, {
      width: chartWidth,
      height: chartHeight,
      layout: {
        backgroundColor: '#000000',
        textColor: 'rgba(255, 255, 255, 0.9)',
      },
      grid: {
        vertLines: {
          color: 'rgba(197, 203, 206, 0.5)',
        },
        horzLines: {
          color: 'rgba(197, 203, 206, 0.5)',
        },
      },
      crosshair: {
        mode: LightweightCharts.CrosshairMode.Normal,
      },
      priceScale: {
        borderColor: 'rgba(197, 203, 206, 0.8)',
      },
      rightPriceScale: {
        scaleMargins: {
          top: 0.2,
          bottom: 0.1,
        },
      },
      timeScale: {
        rightOffset: 2,
        borderColor: 'rgba(197, 203, 206, 0.8)',
        timeVisible: true,
        secondsVisible: false,
      },
    });

    chart<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.applyOptions({
      watermark: {
        color: 'rgba(170, 175, 180, 0.5)',
        visible: true,
        text: '<?php echo e($symbol[0]); ?>',
        fontSize: 22,
        horzAlign: 'left',
        vertAlign: 'top',
      },
    });

    chart<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.subscribeClick(function(param){
      console.log(`An user clicks at (${param.point.x}, ${param.point.y}) point, the time is ${param.time}`);
      console.log(candleSeries<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.coordinateToPrice(param.point.x));
    });

    var candleSeries<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?> = chart<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.addCandlestickSeries({
      upColor: '#00ff00',
      downColor: '#ff0000',
      borderDownColor: 'rgba(255, 144, 0, 1)',
      borderUpColor: 'rgba(255, 144, 0, 1)',
      wickDownColor: 'rgba(255, 144, 0, 1)',
      wickUpColor: 'rgba(255, 144, 0, 1)',
      priceFormat: { type: 'price', minMove: 0.0001, precision: 4 },
      scaleMargins: {
        top: 1,
        bottom: 0.05,
      },
    });

    // create a horizontal price line at a certain price level.
    <?php if(isset($symbol[1])): ?>
    <?php $__currentLoopData = $symbol[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    const buypriceLine<?php echo e($tick); ?><?php echo e($symbol[0]); ?><?php echo e($key); ?> = candleSeries<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.createPriceLine({
          price: <?php echo e($buy); ?>,
          color: 'red',
          lineWidth: 2,
          lineStyle: LightweightCharts.LineStyle.Dotted,
          axisLabelVisible: true,
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(isset($symbol[2])): ?>
    <?php $__currentLoopData = $symbol[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    const sellpriceLine<?php echo e($tick); ?><?php echo e($symbol[0]); ?><?php echo e($key); ?> = candleSeries<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.createPriceLine({
          price: <?php echo e($sell); ?>,
          color: 'green',
          lineWidth: 2,
          lineStyle: LightweightCharts.LineStyle.Dotted,
          axisLabelVisible: true,
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    fetch('https://api.binance.com/api/v3/klines?symbol=<?php echo e($symbol[0]); ?>&interval=<?php echo e($tick); ?>&limit=1000')
      .then((r) => r.json())
      .then((response) => {
        //console.log('response_binance', response)
        var objs = response.map(function(x) {
          return {
            time: x[0] / 1000 + 60*60*2,
            open: x[1],
            high: x[2],
            low: x[3],
            close: x[4],
            value: x[5]*x[4],
            color: x[1] > x[4] ? 'rgba(255,82,82, 0.8)' : 'rgba(0, 150, 136, 0.8)'
          };
        });
        console.log(objs);
        //console.log('response_data', data)
        candleSeries<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.setData(objs);
        histogramSeries<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.setData(objs);
      })

    const histogramSeries<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?> = chart<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.addHistogramSeries({
      color: '#26a69a',
      priceFormat: {
        type: 'volume',
      },
      priceScaleId: '',
      scaleMargins: {
        top: 0.90,
        bottom: 0,
      },
    });

// set markers
    candleSeries<?php echo e($tick); ?>_<?php echo e($symbol[0]); ?>.setMarkers([
      <?php $__currentLoopData = $symbol[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      {
        time: <?php echo e($marker->time + 60*60*2); ?>,
        position: '<?php echo e($marker->position); ?>',
        color: '<?php echo e($marker->color); ?>',
        shape: '<?php echo e($marker->shape); ?>',
        id: '<?php echo e($marker->id); ?>',
        text: '<?php echo e($marker->text); ?>',
        size: 1,
      },
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]);

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    // /stream?streams=<streamName1>/<streamName2>/<streamName3>
    //var binanceSocket = new WebSocket("wss://stream.binance.com:9443/ws/btcusdt@kline_1m");
    //var binanceSocket = new WebSocket("wss://stream.binance.com:9443/stream?streams=btcusdt@kline_1m/ethusdt@kline_1m/bnbusdt@kline_1m/ethbtc@kline_1m");
    var binanceSocket = new WebSocket("wss://stream.binance.com:9443/stream?streams=<?php echo e($link); ?>");

    binanceSocket.onmessage = function(event) {
      var message = JSON.parse(event.data);

      if (message.stream == 'bnbbusd@kline_1m') bnb = message.data.k.c*1;
      if (message.stream == 'ethbusd@kline_1m') eth = message.data.k.c*1;
      if (message.stream == 'btcbusd@kline_1m') btc = message.data.k.c*1;
      document.title = bnb + ' ' + eth + ' ' + btc;

      //console.log('message', message)
      <?php $__currentLoopData = $symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      if (message.stream == '<?php echo e(strtolower($symbol[0])); ?>@kline_1m') {
        var candlestick = message.data.k;
        candleSeries1m_<?php echo e($symbol[0]); ?>.update({
          time: candlestick.t / 1000 + 60*60*2,
          open: candlestick.o,
          high: candlestick.h,
          low: candlestick.l,
          close: candlestick.c,
        });
        histogramSeries1m_<?php echo e($symbol[0]); ?>.update({
          time: candlestick.t / 1000 + 60*60*2,
          value: candlestick.v * candlestick.c,
          color: candlestick.o > candlestick.c ? 'rgba(255,82,82, 0.8)' : 'rgba(0, 150, 136, 0.8)'
        });
      }
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      //var candlestick = message.k;

      //console.log('candlestick', candlestick)

    }

  </script>
</body>

</html>
<?php /**PATH C:\git\testing\laravel\vanilla\resources\views/klines/index.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      <?php echo e(__('Portfolio')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 bg-gray-100 border-b border-gray-200">
          <div id="app">
            <?php if(count($balance) > 0): ?>
            <?php $__currentLoopData = $balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin => $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p title="<?php echo e($asset->name); ?> <?php echo e(round($asset->price,2)); ?>"><?php echo e($asset->name); ?>: <?php echo e($asset->total); ?> <?php echo e($coin); ?> (<span id="<?php echo e($coin); ?>"><?php echo e(round($asset->price,2)); ?></span> kn)</p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p> Total: <span id="total"><?php echo e(round($total,2)); ?></span> kn</p>
            <?php else: ?>
            <p> No assets found</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
    <script>
    var binanceSocket = new WebSocket("wss://stream.binance.com:9443/stream?streams=adabusd@kline_1m/bnbbusd@kline_1m/ethbusd@kline_1m/maticbusd@kline_1m/btcbusd@kline_1m");
    <?php $__currentLoopData = $balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin => $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    var <?php echo e(strtolower($coin)); ?> = <?php echo e($balance[$coin]->price); ?>;
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    // Create our number formatter.
    var formatter = new Intl.NumberFormat('hr-HR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    binanceSocket.onmessage = function(event) {
      var message = JSON.parse(event.data);
      <?php $__currentLoopData = $balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin => $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      if (message.stream == '<?php echo e(strtolower($coin)); ?>busd@kline_1m') {
        <?php echo e(strtolower($coin)); ?> = message.data.k.c * <?php echo e($balance[$coin]->total); ?> * <?php echo e($busd_kn); ?>;
        document.getElementById('<?php echo e($coin); ?>').innerHTML = formatter.format(<?php echo e(strtolower($coin)); ?>,2);
      }
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      var total = 0;
      <?php $__currentLoopData = $balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin => $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      total = total + <?php echo e(strtolower($coin)); ?>;
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      document.getElementById('total').innerHTML = formatter.format(total,2);
      document.title = formatter.format(total,2);
    }

  </script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\git\testing\laravel\vanilla\resources\views/binance/portfolio.blade.php ENDPATH**/ ?>
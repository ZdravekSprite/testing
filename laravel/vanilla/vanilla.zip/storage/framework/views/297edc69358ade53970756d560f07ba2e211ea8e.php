<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      <?php echo e(__('Trades')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
    <div class="max-w-9xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 bg-white border-b border-gray-200">
          <table class="table-auto w-full">
            <thead>
              <tr>
                <th>
                </th>
                <th>
                </th>
                <?php if(count($symbols) > 0): ?>
                <?php $__currentLoopData = $trades[0]->assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin => $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th title="<?php echo e($asset->name); ?> <?php echo e(isset($balance[$coin]) ? $balance[$coin] : ''); ?>"><?php echo e($coin); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p> No symbols found</p>
                <?php endif; ?>
                <th>
                </th>
              </tr>
            </thead>
            <tbody class="text-sm">
              <?php if(count($trades) > 0): ?>
              <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr style="color:<?php if($trade->orderListId == -2): ?> <?php if($trade->isBuyer): ?> blue <?php else: ?> tomato <?php endif; ?> <?php else: ?> <?php if($trade->isBuyer): ?> red <?php else: ?> green <?php endif; ?> <?php endif; ?>;" >
                <td title="<?php echo e($trade->price); ?> <?php echo e($trade->qty); ?> <?php echo e($trade->isBuyer ? 'BUY' : 'SELL'); ?> <?php echo e($trade->quoteQty); ?> <?php echo e($trade->commission); ?> <?php echo e($trade->commissionAsset); ?>">
                  <?php echo e(gmdate("Y-m-d H:i:s", $trade->time / 1000)); ?> <?php echo e($trade->symbol); ?>

                </td>
                <td>
                  <?php echo e(round($trade->total_kn, 2)); ?>kn
                </td>
                <?php if($trade->assets): ?>
                <?php $__currentLoopData = $trade->assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin => $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td><?php echo e(round($asset->total, 8)); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <p> No trades found</p>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\git\testing\laravel\vanilla\resources\views/trades/index.blade.php ENDPATH**/ ?>
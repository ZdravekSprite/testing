<?php

namespace Database\Factories;

use App\Models\Hnb;
use Illuminate\Database\Eloquent\Factories\Factory;

class HnbFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Hnb::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}

<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Jezične linije za provjeru autentičnosti
    |--------------------------------------------------------------------------
    |
    | Sljedeće jezične linije koriste se tijekom autentifikacije za razne
    | poruke koje moramo prikazati korisniku. Slobodni ste izmijeniti ove
    | jezične linije prema zahtjevima vaše aplikacije.
    |
    */

    'failed' => 'Ove vjerodajnice ne odgovaraju našim podacima.',
    'throttle' => 'Previše pokušaja prijave. Pokušajte ponovo za :seconds sekunde.',

];
